using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OwnCards : MonoBehaviour
{
    public List<Card> cards = new List<Card>();
    public int maxCards = 6;
    
}
